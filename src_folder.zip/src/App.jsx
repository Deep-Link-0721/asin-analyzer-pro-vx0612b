
import React, { useState } from 'react';
import Papa from 'papaparse';
import { CSVLink } from 'react-csv';
import { Line } from 'react-chartjs-2';

export default function App() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Amazon広告分析アプリ</h1>
    </div>
  );
}
